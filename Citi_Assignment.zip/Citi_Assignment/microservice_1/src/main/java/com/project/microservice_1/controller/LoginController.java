package com.project.microservice_1.controller;


import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

@Controller

public class LoginController {

    @Autowired
    RestTemplate restTemplate;

    public static final String LOGIN_SERVICE="login-service";

    @GetMapping("/login")
    public String login(){
        return "login";
    }

/*    TO CHECK THE LOGIN CREDENTIALS ENTERED BY THE USER,
        IF THE CREDENTIALS ARE RIGHT IT WILL TAKE YOU TO THE DASHBOARD
        IF THE CREDENTIALS ARE WRONG IT WILL GIVE YOU AN ERROR MESSAGE AND TAKES YOU BACK TO LOGIN PAGE */

    @PostMapping("/checkCredentials")
    @CircuitBreaker(name=LOGIN_SERVICE, fallbackMethod = "A")

    public String loginHomePage(@RequestParam("userName") String userName,
                                @RequestParam("password") String password) {
        System.out.println("UserName: "+ userName);
        System.out.println("Password: "+ password);

        String response = restTemplate.exchange("http://authentication-service/checkCredentials/{userName}/{password}",
                HttpMethod.GET, null, new ParameterizedTypeReference<String>() {
                }, userName, password).getBody();

        if(response.equals("true")){
            return "loginSuccessfulDashboard";
        }
        else{
            return "loginFailedDashboard";
        }

    }

/*   TO SAVE THE USER DETAILS OF NEW USER,
        IF THE CREDENTIALS ARE SAVED INTO THE DATABASE THEN IT WILL YOU GIVE A SUCCESSFULLY SAVED MESSAGE,
        IF THE CREDENTIALS ARE NOT SAVED IT WILL GIVE AN ERROR MESSAGE   */

    @PostMapping("/saveNewUserDetails")
    @CircuitBreaker(name=LOGIN_SERVICE, fallbackMethod = "A")
    public String savingUserData(@RequestParam("name") String name,
                                 @RequestParam("age") int age,
                                 @RequestParam("userName") String userName,
                                 @RequestParam("password") String password){

        System.out.println("name: "+ name);
        System.out.println("age "+ age);
        System.out.println("UserName: "+ userName);
        System.out.println("Password: "+ password);
        String response = restTemplate.exchange("http://authentication-service/saveDetails/{name}/{age}/{userName}/{password}",
                HttpMethod.GET, null, new ParameterizedTypeReference<String>() {
                },name, age, userName, password).getBody();

        if(response.equals("true")){
            return "SignedUpDashboard";
        }
        else{
            return "loginFailedDashboard";
        }
    }

    public String A(Exception e){
        return "hello";
    }


    @PostMapping("/login")
    public String loginPost(){
        return "login";
    }

    @PostMapping("/registration")
    public String register(){
        return "registration";
    }

    @PostMapping("/SignedUpDashboard")
    public String dashboard2(){
        return "SignedUpDashboard";
    }

    @PostMapping("/loginFailedDashboard")
    public String dashboar(){
        return "loginFailedDashboard";
    }



}
