package com.project.microservice_2.controller;

import com.project.microservice_2.model.User;
import com.project.microservice_2.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController

public class AuthenticationController {

    @Autowired
    UserRepository userRepository;

    @GetMapping("/checkCredentials/{userName}/{password}")
    public String credentialsAuthentication(@PathVariable("userName") String userName, @PathVariable("password") String password){
        System.out.println("userName received: "+ userName);
        System.out.println("password received: "+ password);
//        boolean response =userRepository.existsById(userName);
//        System.out.println(response);
        if(userRepository.findById(userName).isPresent()){
            System.out.println("inside first if");
            String dummy = userRepository.findById(userName).toString();
//            System.out.println("string dummy: "+ dummy);
            String[] passwordSubString = dummy.split(",");
//            System.out.println(passwordSubString[3]);
            String[] passwordString = passwordSubString[3].split("'");
            System.out.println("password entered by user: "+ passwordString[1]);

            if(password.equals(passwordString[1])){
                return "true";
            }
            else{
                return "false";
            }
        }
        else{
            return "false";
        }

    }
    @GetMapping("/saveDetails/{name}/{age}/{userName}/{password}")
    public String savingUserDetails(@PathVariable("name") String name,@PathVariable("age") int age,
                                    @PathVariable("userName") String userName, @PathVariable("password") String password){
        System.out.println("name received: "+ name);
        System.out.println("age received: "+ age);
        System.out.println("userName received: "+ userName);
        System.out.println("password received: "+ password);
        User user = new User(name, age, userName, password);
        userRepository.save(user);
        if(userRepository.findById(userName).isPresent()){
            return "true";
        }
        else{
            return "false";
        }
    }
}
